# Maestro Shifu — landing de video

Landing estática en HTML, CSS y JavaScript. No requiere Node.js ni proceso de build.

## Archivos

- `index.html`: página principal.
- `media/video.mp4`: coloca aquí el video de presentación (no incluido en este paquete).

## Publicación

Publica el contenido de este repositorio desde la raíz (`/`). En Hostinger, selecciona la rama `main` y usa la raíz del repositorio como directorio de despliegue.

## Video

El HTML espera el archivo en `media/video.mp4`. Debe ser MP4 y el nombre debe coincidir exactamente.

La redirección está configurada para ejecutarse cuando el evento `ended` del video se dispara:

`https://uplcm.com/4/10118997`

Nota: algunos navegadores bloquean la reproducción automática con audio. Por eso el video inicia silenciado y permite activar el sonido manualmente.
